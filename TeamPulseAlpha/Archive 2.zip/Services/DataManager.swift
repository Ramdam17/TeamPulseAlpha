//
//  DataManager.swift
//  TeamPulseAlpha
//
//  Created by blackstar on 23/07/2024.
//

import CoreData

class DataManager {
    static let shared = DataManager()

    private init() {}
    
    func resetSensors() {
        let context = CoreDataStack.shared.context
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = SensorEntity.fetchRequest()
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)

        do {
            try context.execute(deleteRequest)
            try context.save()
            initializeSensors() // Re-initialize sensors after deletion
        } catch {
            print("Failed to reset sensors: \(error)")
        }
    }

    func initializeSensors() {
        let context = CoreDataStack.shared.context
        let fetchRequest: NSFetchRequest<SensorEntity> = SensorEntity.fetchRequest()

        do {
            let sensors = try context.fetch(fetchRequest)
            if sensors.count < 3 {
                createSensor(macAddress: "0F099F27-18D8-8ACC-C895-54AC2C36C790", color: "Blue")
                createSensor(macAddress: "F3742462-63F6-131A-C487-9F78D8A4FCCC", color: "Green")
                createSensor(macAddress: "EA61A349-6EFF-9A05-F9C1-F610C171579F", color: "Red")
            }
        } catch {
            print("Failed to fetch sensors: \(error)")
        }
    }

    private func createSensor(macAddress: String, color: String) {
        let context = CoreDataStack.shared.context
        let sensor = SensorEntity(context: context)
        sensor.id = UUID()
        sensor.macAddress = macAddress
        sensor.color = color
        sensor.isConnected = false
        CoreDataStack.shared.saveContext()
    }
}
