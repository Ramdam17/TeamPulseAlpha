//
//  SensorEntity+CoreDataClass.swift
//  TeamPulseAlpha
//
//  Created by blackstar on 23/07/2024.
//
//

import Foundation
import CoreData


public class SensorEntity: NSManagedObject {

}
