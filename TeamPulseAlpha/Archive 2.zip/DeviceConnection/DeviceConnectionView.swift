//
//  DeviceConnectionView.swift
//  TeamPulseAlpha
//
//  Created by blackstar on 23/07/2024.
//

import SwiftUI

struct DeviceConnectionView: View {
    @EnvironmentObject var bluetoothManager: BluetoothManager

    var body: some View {
        VStack {
            Text("Device Connection")
                .font(.largeTitle)
                .padding()

            List {
                ForEach(bluetoothManager.sensors) { sensor in
                    HStack {
                        Text("Sensor \(sensor.color)")
                        Spacer()
                        Text(sensor.isConnected ? "Connected" : "Searching")
                            .foregroundColor(sensor.isConnected ? .green : .red)
                    }
                }
            }

            if bluetoothManager.isScanning {
                Text("Scanning for sensors...")
                    .padding()
            } else if bluetoothManager.sensors.allSatisfy({ $0.isConnected }) {
                Button(action: {
                    // Navigate to the next screen
                    print("Navigating to the next screen")
                }) {
                    Text("Go to Next Screen")
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }
                .padding()
            } else {
                Text("Waiting for all sensors to connect...")
                    .padding()
            }
        }
        .onAppear {
            bluetoothManager.startScanning()
        }
        .onChange(of: bluetoothManager.isScanning) {
            print("isScanning state changed: \(bluetoothManager.isScanning)")
        }
        .onChange(of: bluetoothManager.sensors) {
            print("Sensor states changed: \(bluetoothManager.sensors.map { "\($0.color): \($0.isConnected)" })")
        }
    }
}
