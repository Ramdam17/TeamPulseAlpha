//
//  BluetoothManager.swift.swift
//  TeamPulseAlpha
//
//  Created by blackstar on 24/07/2024.
//

import CoreBluetooth
import CoreData
import Foundation

class BluetoothManager: NSObject, ObservableObject {
    @Published var sensors: [SensorEntity] = []
    @Published var isScanning = false
    
    private var centralManager: CBCentralManager!
    private var discoveredPeripherals: [String: CBPeripheral] = [:]
    private var allSensorsConnected = false // Add this flag to control scanning
    
    override init() {
        super.init()
        centralManager = CBCentralManager(delegate: self, queue: nil)
        fetchSensors()
    }
    
    func fetchSensors() {
        let fetchRequest: NSFetchRequest<SensorEntity> = SensorEntity.fetchRequest()
        do {
            sensors = try CoreDataStack.shared.context.fetch(fetchRequest)
            print("Fetched sensors from CoreData: \(sensors.map { $0.macAddress })")
        } catch {
            print("Failed to fetch sensors: \(error)")
        }
    }
    
    func startScanning() {
        guard !allSensorsConnected else {
            print("All sensors are already connected. Skipping scan.")
            return
        }
        
        isScanning = true
        print("Starting scan for peripherals...")
        centralManager.scanForPeripherals(withServices: nil, options: nil)
    }
    
    func stopScanning() {
        isScanning = false
        print("Stopping scan for peripherals.")
        centralManager.stopScan()
    }
    
    func connectToSensors() {
        print("Attempting to connect to sensors...")
        for sensor in sensors where discoveredPeripherals[sensor.macAddress] != nil {
            let peripheral = discoveredPeripherals[sensor.macAddress]!
            print("Connecting to sensor with UUID: \(sensor.macAddress)")
            centralManager.connect(peripheral, options: nil)
        }
    }
    
    func checkIfAllSensorsConnected() {
        let allConnected = sensors.allSatisfy { $0.isConnected }
        print("Checking if all sensors are connected. Result: \(allConnected)")
        
        if allConnected {
            print("All sensors connected. Stopping scan.")
            stopScanning()
            allSensorsConnected = true // Update the flag to indicate all sensors are connected
            
            // Trigger UI update or notify that all sensors are connected
            DispatchQueue.main.async {
                self.isScanning = false // This can be used to trigger UI changes
                print("Scanning stopped, updating UI.")
            }
        } else {
            print("Not all sensors are connected yet.")
        }
    }
}

extension BluetoothManager: CBCentralManagerDelegate, CBPeripheralDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            print("Bluetooth is powered on.")
            startScanning()
        } else {
            print("Bluetooth is not available. State: \(central.state.rawValue)")
            stopScanning()
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String: Any], rssi RSSI: NSNumber) {
        let peripheralUUID = peripheral.identifier.uuidString
        print("Discovered peripheral with UUID: \(peripheralUUID)")

        // Matching the peripheral UUID with the stored sensor UUIDs
        if let sensor = sensors.first(where: { $0.macAddress == peripheralUUID }) {
            print("Matched sensor with UUID: \(peripheralUUID)")
            discoveredPeripherals[peripheralUUID] = peripheral
            sensor.isConnected = true
            
            // Connect to the peripheral without stopping the scan
            connectToSensor(peripheral)
        } else {
            print("Peripheral with UUID \(peripheralUUID) does not match any known sensors.")
        }
    }
    
    func connectToSensor(_ peripheral: CBPeripheral) {
        print("Connecting to sensor with UUID: \(peripheral.identifier.uuidString)")
        centralManager.connect(peripheral, options: nil)
    }
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        let uuid = peripheral.identifier.uuidString
        print("Successfully connected to peripheral with UUID: \(uuid)")
        
        if let sensor = sensors.first(where: { $0.macAddress == uuid }) {
            sensor.isConnected = true
            print("Sensor \(sensor.color) is now marked as connected.")
            peripheral.delegate = self
            print("Discovering services for peripheral with UUID: \(uuid)")
            peripheral.discoverServices([CBUUID(string: "180D")])
            
            // Check if all sensors are connected
            checkIfAllSensorsConnected()
        } else {
            print("Error: Connected peripheral with UUID \(uuid) does not match any sensor in the list.")
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let error = error {
            print("Error discovering services: \(error.localizedDescription)")
            return
        }

        if let services = peripheral.services {
            for service in services {
                print("Discovered service with UUID: \(service.uuid)")
                if service.uuid == CBUUID(string: "180D") {
                    print("Discovering characteristics for service with UUID: \(service.uuid)")
                    peripheral.discoverCharacteristics([CBUUID(string: "2A37")], for: service)
                }
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        if let error = error {
            print("Error discovering characteristics: \(error.localizedDescription)")
            return
        }

        if let characteristics = service.characteristics {
            for characteristic in characteristics {
                print("Discovered characteristic with UUID: \(characteristic.uuid)")
                if characteristic.uuid == CBUUID(string: "2A37") {
                    print("Subscribing to notifications for characteristic with UUID: \(characteristic.uuid)")
                    peripheral.setNotifyValue(true, for: characteristic)
                }
            }
        }
    }
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        if let error = error {
            print("Error updating value for characteristic: \(error.localizedDescription)")
            return
        }
        
        guard let data = characteristic.value else { return }

        if characteristic.uuid == CBUUID(string: "2A37") {
            let (heartRate, IBI) = parseHeartRateMeasurement(data)
            print("Heart Rate: \(heartRate), IBI: \(IBI)")
            // Handle the heart rate and IBI values as needed
        }
    }
    
    private func parseHeartRateMeasurement(_ data: Data) -> (heartRate: Int, IBI: [Double]) {
        let flag = data[0]
        var heartRate = 0
        var IBI: [Double] = []

        if flag & 0x01 == 0 {
            // Heart rate is in one byte
            heartRate = Int(data[1])

            if data.count >= 4 {
                let rr = Double(UInt16(data[2]) | UInt16(data[3]) << 8) / 1024.0
                IBI.append(rr)
            }
            if data.count >= 6 {
                let rr = Double(UInt16(data[4]) | UInt16(data[5]) << 8) / 1024.0
                IBI.append(rr)
            }
            if data.count >= 8 {
                let rr = Double(UInt16(data[6]) | UInt16(data[7]) << 8) / 1024.0
                IBI.append(rr)
            }
        } else {
            // Heart rate is in two bytes (16 bits)
            heartRate = Int(UInt16(data[1]) | UInt16(data[2]) << 8)
        }

        return (heartRate, IBI)
    }
}
